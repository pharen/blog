

import Foundation

class MyObj: NSObject {
    dynamic var index = 0;
}


class TestKVO: NSObject {
    
    var myObj = MyObj()
    
    override init() {
        super.init()
        print("index当前值为\(myObj.index)")
        myObj.addObserver(self, forKeyPath: "index", options: .New, context: &myObj)
    }
    
    override func observeValueForKeyPath(keyPath: String?, ofObject object: AnyObject?, change: [String : AnyObject]?, context: UnsafeMutablePointer<Void>) {
        if context == &myObj {
            print("MyObj属性index发生变化，值为：\(change![NSKeyValueChangeNewKey])")
        }
    }
}


let testKVO = TestKVO()
testKVO.myObj.index = 2
